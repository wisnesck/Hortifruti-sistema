#include <iostream>
#include <vector>
using namespace std;

int opcao = 0;

void menu() {
    cout << "-------------- MENU --------------" << endl;
    cout << "----------------------------------" << endl;
    cout << "---- Digite a opcao desejada: ----" << endl;
    cout << endl;
    cout << "\t1. Inserir Produto" << endl;
    cout << "\t2. Exibir Produtos" << endl;
    cout << "\t3. Buscar Produtos" << endl;
    cout << "\t4. Excluir um Produto" << endl;
    cout << "\t5. Sair do Sistema" << endl;
    cout << endl; // espaçamento entre as linhas
    cin >> opcao;
    cout << endl;
}

int main() {
    string nomeProduto, continuar;
    int qntProduto;
    vector<pair<string, int>> produtos; // vetor que armazena pares (nome do produto, quantidade)

    while (opcao != 5) {
        menu();

        switch (opcao) {
            case 1:
                do {
                    cout << "Digite o nome do Produto: " << endl;
                    cout << ">> ";
                    cin >> nomeProduto;
                    cout << endl;
                    cout << "Digite a quantidade: " << endl;
                    cin >> qntProduto;
                    cout << endl;

                    bool produtoEncontrado = false;

                    // ver se o produto digitado ja esta na lista (se tiver, vai somar o valor atual com o valor que ja possuia nele anteriormente) 
                    // percorre minha lista
                    // verifica se ja possui esse produto na lista
                    // se ja tiver,acrescenta a quantidade no produto ja existente

                    for (int i = 0; i < produtos.size(); i++){ 
                        if(produtos[i].first == nomeProduto) { 
                            produtos[i].second += qntProduto; 
                            produtoEncontrado = true;
                            cout << "Quantidade atualizada para o produto: " << nomeProduto << endl;
                            break;
                        }
                    }

                    // condição feita para acrescentar um novo produto na lista, caso esse produto digitado ainda não esteja nela.
                    // sintaxe ".push_back" -> armazena o produto e a quantidade

                    if (!produtoEncontrado) { 
                        produtos.push_back(make_pair(nomeProduto, qntProduto));
                        cout << endl;
                        cout << "Produto adicionado com sucesso!" << endl;
                        cout << endl;
                    }
                    
                    // verifica se precisa adicionar outro produto

                    cout << "Deseja adicionar outro produto? (s/n): ";
                    cin >> continuar;
                    cout << endl;

                } while (continuar == "s" || continuar == "S"); 

                // while -> vai repetir todo esse processo sempre que digitar S ou s -> obs: usei o do while, porque ele vai sempre executar o menu pelo menos uma vez antes de testar o codigo (mesmo que dê errado).

                break;

            case 2:

                //condiçao para quando nao tiver nenhum produto na lista
                // se tiver produtos em estoque, vai executar
                // percorrer toda a lista de produtos
                // mostra todos os produtos na lista

                if (produtos.empty()) { 
                    cout << "Nenhum produto em estoque!" << endl;
                } else {
                    cout << "Produtos em estoque: " << endl; 

                    for (size_t i = 0; i < produtos.size(); i++) { 

                    
                        cout << "ID:" << i + 1 << " - Produto: " << produtos[i].first 
                             << " - Quantidade: " << produtos[i].second << endl; 
                    }
                }
                cout << endl;
                break;


            // usa colchetes porque estou declarando uma variavel dentro desse bloco case
            // forma compacta de um loop for para iterar sobre todos os elementos do vetor produtos
            // vou ver se o prod digitado é = a algum produto da lista
            // se tiver esse produto na lista, irá aparecer ele e a quantidade dele.

            case 3: {
                string nomeBusca;

                cout << "Digite o nome do produto para buscar: ";
                cin >> nomeBusca;
                bool encontrado = false;

                for (const auto& produto : produtos) { 
                    if (produto.first == nomeBusca) { 
                        cout << "\nNome: " << produto.first << " - Quantidade: " << produto.second << endl;
                        encontrado = true; 

                        break;
                    }
                }
                
                // condição para caso não tiver na lista o produto digitado na busca.

                if (!encontrado) { 
                    cout << "Produto nao encontrado!" << endl;
                }

                cout << endl;
                break; 
            }

            //percorre todos os itens da lista novamente
            //vou mostrar novamente os produtos que possuo na minha lista

            case 4: {

                string delProduto;

                cout << "Qual desses itens deseja deletar?" << endl;
             
                cout << endl;
                
                if(produtos.empty()) {
                    cout << "Não possui nenhum produto na sua lista" << endl;
                } else {
                    for (size_t i = 0; i < produtos.size(); i++) { 

                        cout << "ID:" << i + 1 << " - Produto: " << produtos[i].first 
                             << " - Quantidade: " << produtos[i].second << endl; 
                    }

                    cout << endl;
                    cout << "Digite o nome do produto para remover: " << endl;
                    cin >> delProduto;
                    cout << endl;

                    bool produtoEncontrado = false;

                    // percorre a lista de novo
                    // se prod (indice dele) que digitou tiver na lista
                    // ".eraser" -> sintaxe para apagar o indice onde esta esse produto
                    // boolean true confirmando a exclusão do item

                    for (size_t i = 0; i < produtos.size(); i++) { 
                        if (produtos[i].first == delProduto) { 
                            produtos.erase(produtos.begin() + i); 

                            cout << "Produto " << delProduto << " removido com sucesso!" << endl;
                            produtoEncontrado = true; 

                            break; 
                        }
                    }
                    
                    // condiçao caso o produto não tenha sido encontrado

                    if (!produtoEncontrado) { 
                        cout << "Produto nao encontrado!" << endl; 
                    }
                }

                break;
            }

            // finalizando programa
            default:
                cout << "Saindo..." << endl; 
        }
    }

    return 0;
}
